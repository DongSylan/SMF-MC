%% Initialize the enviroment
    clear
    close all
    clc
%     rng('default')

%% Input the task types
    Task_Type = 'RandMask';  % Three Types: 'RandMask';  'ScribblingStroke'; 'Text'

   
%% Load & Process the data and toolbox
  % Load the data Images
    FileName_NaturalImages = 'NaturalImages'; % NaturalImages (.jpg) 
    Type_ColorImages = '.jpg';
    Dir_Images = dir(fullfile(FileName_NaturalImages, ['*' Type_ColorImages]));
    FullName_Images = {Dir_Images.name};  
    Number_Images = length(FullName_Images);
  % Load the toolboxes
    PATH_Functions_Public = genpath('Functions_Public');
    addpath(PATH_Functions_Public);
    PATH_Functions_IRNN = genpath('Functions_IRNN');
    addpath(PATH_Functions_IRNN);
    PATH_Functions_MSS = genpath('Functions_MSS');
    addpath(PATH_Functions_MSS);
    
    
%% Parameter setting 
  % Public parameters
    epsilon = 1e-5;
    MaxIter = 500;
    SR_Selected = 50;
    SR_Set = [20, 30, 40, 50];
  % Load the images
    Index_Image = randperm(Number_Images, 1);
    FullName_Image_ith = strcat([FileName_NaturalImages '\'], FullName_Images{Index_Image});
    Image_uint8 = imread(FullName_Image_ith);
    [n1, n2, n3] = size(Image_uint8);
    n1A2_min = min(n1, n2);
    r_estimate = min(ceil(0.3*n1A2_min), n1A2_min);
  % Set the sampling index of different tasks
    if isequal(Task_Type, 'RandMask')
        Index_channel = randi(100, n1, n2);
        Omega = Index_channel < SR_Selected;
        disp('The task is to recover the matrices with rand mask.')
    elseif isequal(Task_Type, 'ScribblingStroke') || isequal(Task_Type, 'Text')
        Data_NonRandomMask = double(imread([Task_Type '.jpg']));
        [n1, n2, n3] = size(Data_NonRandomMask);
        if n3 == 3
            Matrix_NonRandomMask = zeros(n1, n2);
            for i = 1:3
                Matrix_NonRandomMask = Matrix_NonRandomMask + Data_NonRandomMask(:, :, i)/3;
            end
        else
            Matrix_NonRandomMask = Data_NonRandomMask;
        end
        Omega = Matrix_NonRandomMask >= 200;
        if isequal(Task_Type, 'ScribblingStroke')
            disp('The task is to recover the matrices maked with the scribbling stroke.')
        else
            disp('The task is to recover the matrices masked with the text.')
        end 
    else
        disp('Please provide the canonical name of the task, i.e, ''RandMask'', ''ScribblingStroke'' and ''Text''.')
    end
    
  % Parameters for SMF-AM
    r_AM = r_estimate;
    % Smooth matrix
    Rn1 = TVmatrix_Generotor(n1);
    Rn2 = TVmatrix_Generotor(n2);
    Rn1tRn1 = Rn1'*Rn1;
    Rn2tRn2 = Rn2'*Rn2;
    lambda_AM = sqrt(max([n1, n2]));
    Para_AM.MaxIter = MaxIter;
    Para_AM.epsilon = epsilon;
    Para_AM.gamma  = lambda_AM/50;
    Para_AM.V_k = rand(n2, r_estimate);
    Para_AM.X_k = rand(n1, n2);
    
  % Parameters for SMF-AAM
    r_AAM = r_estimate;
    lambda_AAM = lambda_AM;
    Para_AAM.MaxIter = MaxIter;
    Para_AAM.epsilon = epsilon;
    Para_AAM.gamma  = lambda_AAM/100;
    Para_AAM.U_k = rand(n1, r_estimate);
    Para_AAM.V_k = rand(n2, r_estimate);
    Para_AAM.X_k = rand(n1, n2);
    
    
%% MC via SMF-AM & SMF-AAM
    tic
    [Image_AM, PSNR_AM, SSIM_AM] = AM_Image(Image_uint8, Omega, r_AM, Rn1tRn1, Rn2tRn2, lambda_AM, Para_AM);
    RunningTime_AM = toc;
    tic
    [Image_AAM, PSNR_AAM, SSIM_AAM] = AAM_Image(Image_uint8, Omega, r_AAM, Rn1tRn1, Rn2tRn2, lambda_AAM, Para_AAM);
    RunningTime_AAM = toc;
    
    
%% Show the results
    Omega_tensor = false(n1, n2, n3);
    for index_channel = 1:n3
        Omega_tensor(:, :, index_channel) = Omega;
    end
    % See and save as a whole image
    h = figure;
    subplot(1, 4, 1)
    imshow(Image_uint8);
    title(['The ' num2str(Index_Image) '-th image'])
    subplot(1, 4, 2)
    Demo_Tensor_Omega = double(Image_uint8).*Omega_tensor;
    imshow(uint8(Demo_Tensor_Omega));
    title('Masked image')
    subplot(1, 4, 3)
    imshow(Image_AAM);
    title(['SMF-AM(' char(vpa(PSNR_AM, 4))  '(dB)|' char(vpa(SSIM_AM, 4)) '|' char(vpa(RunningTime_AM, 3)) 's)'] )
    subplot(1, 4, 4)
    imshow(Image_AAM);
    title(['SMF-AAM(' char(vpa(PSNR_AAM, 4))  '(dB)|' char(vpa(SSIM_AAM, 4)) '|' char(vpa(RunningTime_AAM, 3)) 's)'] )
    % Make the obtained figure much larger
    scrsz = get(0, 'ScreenSize');  % to get the size of the screen�� scrsz <=[left,bottom, width, height]
    set(gcf, 'Position', scrsz)
    disp(['It is displaying the recovery results (in the form of PSNR|SSIM|Runningtime) about the ' num2str(Index_Image) '-th image .'])
    


   
