function Rn1  =TVmatrix_Generotor(n1)

%-----------------1-order TV-----------------%
    Rn1_Main = eye(n1) + diag(-ones(n1-1, 1), 1);
    Rn1 = Rn1_Main(1:(end-1), :);
%-----------------1-order TV-----------------%

end