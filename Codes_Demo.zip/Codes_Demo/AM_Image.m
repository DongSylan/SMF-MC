function [Image_AM, PSNR_AM, SSIM_AM] = AM_Image(Image_uint8, Omega, r_estimate, Rn1tRn1, Rn2tRn2, lambda_AM, Para_AM)

% Used to process the color image completion

%% Some parameter settings
 % Public parameters
   n1 = size(Image_uint8, 1);
   n2 = size(Image_uint8, 2);
   n3 = size(Image_uint8, 3);
 % Parameters for algorithm
   OmegaC = ~Omega;

   Data_Image = double(Image_uint8);
   Image_AM = uint8(zeros(n1, n2, n3));
   for channel = 1:n3
       Image_channel = Data_Image(:, :, channel);
       Image_channel_Omega = Image_channel.*Omega;
       Para_AM.M = Image_channel;
       [U_channel_AM, V_channel_AM] = SMF_AM(Image_channel_Omega, Omega, r_estimate, Rn1tRn1, Rn2tRn2, lambda_AM, Para_AM);
       Image_channel_Recovered = U_channel_AM*V_channel_AM';
       Image_channel_AM = Image_channel_Omega + Image_channel_Recovered.*OmegaC;
       Image_channel_AM = max(Image_channel_AM, 0);
       Image_channel_AM = min(Image_channel_AM, 255);
       Image_AM(:, :, channel) = Image_channel_AM; 
   end
   PSNR_AM = psnr(Image_uint8, Image_AM);
   SSIM_AM = ssim(Image_uint8, Image_AM);
 

end