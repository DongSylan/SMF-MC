function [U_Sharp, V_Sharp, RelaError_NeigXiXiPLUS, RelaError_NeigMXiPLUS] = SMF_AAM(M_Omega, Omega, r_estimate, Rn1tRn1, Rn2tRn2, lambda, Parameters)

%% Alternating minimization (AM) algorithm for the following optimization problem: 
 % This code is written for the paper titled "Exact Matrix Completion via Smooth Matrix Factorization" 
 % [EXACT] min_{U,V,X} 0.5(\|U\|_{F}^{2} + \|V\|_{F}^{2}) + 0.5*lambda*(\|R_{n1}U\|_{F}^{2}+\|R_{n2}V\|_{F}^{2}) 
 %         + 0.5*gamma\|X-U*V'\|_{F}^{2},     s.t. X_{Omega} = M_{Omega}

%% Initialize some notations and some settings
  % Notations
    Unknown = 1 - Omega;
    eta1 = max([norm(Rn1tRn1, 2), 1e-3]);
    eta2 = max([norm(Rn2tRn2, 2), 1e-3]);
    Ir_eta1_lambda = (eta1*lambda+1)*eye(r_estimate);
    Ir_eta2_lambda = (eta2*lambda+1)*eye(r_estimate);
    t_kUpdate = @(x) (1+sqrt(1+4*x^2))/2;
  % Parameter settings for AAM algorithm
    U_k = Parameters.U_k;  
    V_k = Parameters.V_k; 
    X_k = Parameters.X_k;   
    gamma = Parameters.gamma;
    MaxIter = Parameters.MaxIter;  
    epsilon = Parameters.epsilon; 
    M = Parameters.M;
   
    
%% Main procedure of the accelerated AM algorithm
    Error_Type1 = zeros(MaxIter, 1);
    Error_Type2 = zeros(MaxIter, 1);
            t_k = 1;
            U_kPLUS1 = U_k;
            V_kPLUS1 = V_k;
            X_kPLUS1 = X_k;
    for k = 1:MaxIter
            t_kPLUS1 = t_kUpdate(t_k);
            w_t = min([(t_k-1)/t_kPLUS1, 0.9999]);
            Uhat_k = U_k + w_t*(U_kPLUS1 - U_k);
            Vhat_k = V_k + w_t*(V_kPLUS1 - V_k);
            t_k = t_kPLUS1;
            U_k = U_kPLUS1;
            V_k = V_kPLUS1;
            X_k = X_kPLUS1;
        
      % Update U_kPLUS1
        A_k = gamma*X_k*V_k + lambda*(eta1*Uhat_k - Rn1tRn1*Uhat_k);
        U_kPLUS1 = A_k/(Ir_eta1_lambda + gamma*(V_k'*V_k));

      % Update V_kPLUS1
        B_k = gamma*X_k'*U_kPLUS1 + lambda*(eta2*Vhat_k - Rn2tRn2*Vhat_k);
        V_kPLUS1 = B_k/(Ir_eta2_lambda + gamma*(U_kPLUS1'*U_kPLUS1));
        
      % Update X_kPLUS1
        UVt_kPLUS1 = U_kPLUS1*V_kPLUS1';
        X_kPLUS1 = M_Omega + UVt_kPLUS1.*Unknown; 
             
      % Compute the relative error on X
        ErrorType1_k = norm(X_kPLUS1 - X_k, 'fro')/max([norm(X_k, 'fro'), 1]);
        Error_Type1(k) = ErrorType1_k;
        M_k = UVt_kPLUS1.*Unknown + M_Omega;
        Error_Type2(k) = norm(M_k - M, 'fro')/norm(M, 'fro');
        
       %-------Check the stopping criterion
        if (k >= 2) && (ErrorType1_k <= epsilon)
            break
        end
        
    end
    
  % Outputs of the algorithm
    U_Sharp = U_kPLUS1;
    V_Sharp = V_kPLUS1;
    RelaError_NeigXiXiPLUS = Error_Type1(1:k);
    RelaError_NeigMXiPLUS = Error_Type2(1:k);
    
end
   
   
   