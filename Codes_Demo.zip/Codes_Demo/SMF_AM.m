function [U_Sharp, V_Sharp, RelaError_NeigXiXiPLUS, RelaError_NeigMXiPLUS] = SMF_AM(M_Omega, Omega, r_estimate, Rn1tRn1, Rn2tRn2, lambda, Parameters)

%% Alternating minimization (AM) algorithm for the following optimization problem: 
 % This code is written for the paper titled "Exact Matrix Completion via Smooth Matrix Factorization" 
 % [EXACT] min_{U,V,X} 0.5(\|U\|_{F}^{2} + \|V\|_{F}^{2}) + 0.5*lambda*(\|R_{n1}U\|_{F}^{2}+\|R_{n2}V\|_{F}^{2}) 
 %         + 0.5*gamma\|X-U*V'\|_{F}^{2},     s.t. X_{Omega} = M_{Omega}


%% Initialize some notations and some settings
  % Notations
    n1 = size(M_Omega, 1);
    n2 = size(M_Omega, 2);
    In1 = 0.5*eye(n1);
    In2 = 0.5*eye(n2);
    Ir = 0.5*eye(r_estimate);
    Unknown = 1 - Omega;
  % Parameter settings for AAM algorithm
    V_k = Parameters.V_k; 
    X_k = Parameters.X_k;   
    gamma = Parameters.gamma;
    MaxIter = Parameters.MaxIter;  
    epsilon = Parameters.epsilon; 
    M = Parameters.M;
   
    
%% Main procedure of the AM algorithm
    Error_Type1 = zeros(MaxIter, 1);
    Error_Type2 = zeros(MaxIter, 1);
    for k = 1:MaxIter

      % Update U_kPLUS1
        A1_k = In1 + lambda*Rn1tRn1;
        B1_k = Ir + gamma*(V_k'*V_k);
        C1_k = gamma*X_k*V_k;
       U_kPLUS1 = sylvester(A1_k, B1_k, C1_k); % sylvester is faster than lyap.
%         U_kPLUS1 = lyap(A1_k, B1_k, -C1_k);

      % Update V_kPLUS1
        A2_k = In2 + lambda*Rn2tRn2;
        B2_k = Ir + gamma*(U_kPLUS1'*U_kPLUS1);
        C2_k = gamma*X_k'*U_kPLUS1;
        V_kPLUS1 = sylvester(A2_k, B2_k, C2_k);
%         V_kPLUS1 = lyap(A2_k, B2_k, -C2_k);
        
      % Update X_kPLUS1
        UVt_kPLUS1 = U_kPLUS1*V_kPLUS1';
        X_kPLUS1 = M_Omega + UVt_kPLUS1.*Unknown;
        
        
      % Compute the relative error on X
        ErrorType1_k = norm(X_kPLUS1 - X_k, 'fro')/max([norm(X_k, 'fro'), 1]);
        Error_Type1(k) = ErrorType1_k;
        M_k = UVt_kPLUS1.*Unknown + M_Omega;
        Error_Type2(k) = norm(M_k - M, 'fro')/norm(M, 'fro');
        
       %-------Check the Stopping Criterion
        if (k >= 2) && (ErrorType1_k <= epsilon)
            break
        else
            V_k = V_kPLUS1;
            X_k = X_kPLUS1;
        end
        
    end
    
  % Outputs of the algorithm
    U_Sharp = U_kPLUS1;
    V_Sharp = V_kPLUS1;
    RelaError_NeigXiXiPLUS = Error_Type1(1:k);
    RelaError_NeigMXiPLUS = Error_Type2(1:k);
    
    
end